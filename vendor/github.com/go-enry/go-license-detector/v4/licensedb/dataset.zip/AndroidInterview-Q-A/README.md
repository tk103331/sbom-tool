### The top Internet companies android interview questions and answers

[![](https://badge.juejin.im/entry/578d938079bc44005ff26aec/likes.svg?style=flat)](https://juejin.im/entry/578d938079bc44005ff26aec/detail)

[Github Repo](https://github.com/JackyAndroid/AndroidInterview-Q-A) welcome star | Github 仓库 欢迎star

[中文版Gitbook](http://www.jackywang.tech/AndroidInterview-Q-A/)

[English Doc](https://github.com/JackyAndroid/AndroidInterview-Q-A/tree/master/english)

English version gitbook is coming soon..

![](http://www.jackywang.tech/images/gongzh.png)
