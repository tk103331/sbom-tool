WaveFunctionCollapse software is mostly under the MIT license. Check individual source files for license text. Provided image samples are not part of WaveFunctionCollapse software.
